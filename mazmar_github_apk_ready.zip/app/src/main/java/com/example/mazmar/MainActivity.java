package com.example.mazmar;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.view.View;
import android.view.WindowManager;
public class MainActivity extends Activity {
 private WebView web;
 private ValueCallback<Uri[]> chooser;
 private static final int FILE_REQUEST=107;
 @Override public void onCreate(Bundle state){super.onCreate(state);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN);
  web=new WebView(this);
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setMediaPlaybackRequiresUserGesture(false);
  web.getSettings().setAllowFileAccess(true);
  web.setWebChromeClient(new WebChromeClient(){
    @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
      if(chooser!=null)chooser.onReceiveValue(null);chooser=cb;
      try {Intent intent=new Intent(Intent.ACTION_GET_CONTENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("audio/*");startActivityForResult(Intent.createChooser(intent,"اختر عينة الصوت"),FILE_REQUEST);return true;}
      catch(Exception ex){chooser=null;return false;}
    }
  });
  setContentView(web);web.loadUrl("file:///android_asset/index.html");
 }
 @Override protected void onActivityResult(int req,int code,Intent data){super.onActivityResult(req,code,data);if(req==FILE_REQUEST&&chooser!=null){chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(code,data));chooser=null;}}
 @Override protected void onDestroy(){if(web!=null)web.destroy();super.onDestroy();}
}
